/*
 * Amanda Tirey
 * Energy to Heat Water Calculator
 * 3/29/2026
 */

import java.util.Scanner;

public class Module2 {
    
    public static void main(String[] args) {
        
        try (Scanner input = new Scanner(System.in)) {
            
            System.out.print("Enter the amount of water in kilograms: ");
            double waterMass = input.nextDouble();

            System.out.print("Enter the initial temperature in Celsius: ");
            double initialTemp = input.nextDouble();

            System.out.print("Enter the final temperature in Celsius: ");
            double finalTemp = input.nextDouble();

            // Calculate energy Q in Joules
            double Q = waterMass * (finalTemp - initialTemp) * 4184;

            System.out.printf("The energy needed is %.2f Joules%n", Q);
        }
    }
}